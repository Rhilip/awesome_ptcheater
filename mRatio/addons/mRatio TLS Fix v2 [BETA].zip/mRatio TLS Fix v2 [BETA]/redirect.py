def request(flow):
	# Due to severely broken proxy support, if a SOCKS5 proxy is used, mRatio:
	#  * always connects on port 80 when announcing to HTTP trackers;
	#  * always connects on port 669 (why!?) when announcing to HTTPS trackers.

	# Therefore, mitmproxy has no way of knowing the real destination port, but we can
	# assume that all HTTPS trackers are on port 443 and all HTTP trackers are on port 80...
		
	if flow.request.scheme == "https":
		flow.request.port = 443
	if flow.request.scheme == "http":
		flow.request.port = 80

	# ...and then handle special cases individually.

	if flow.request.pretty_host == "www.example.invalid":
		flow.request.port = 45000
		flow.request.scheme = 'https'

	if flow.request.pretty_host == "tracker.example.test":
		flow.request.port = 81
		flow.request.scheme = 'http'

	# The problem is that we need to document all trackers with non-standard ports here, and keep track of them whenever they change.
	# A workaround would be to use Proxifier or SocksCap64 instead of mRatio's built-in proxy support, if you don't mind installing another program.
	# In that case, you should delete this script, since it will override the now-correct destination port.
